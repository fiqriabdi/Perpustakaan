<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../config/session.php';

cek_role('mahasiswa');

require_once '../includes/header.php';
require_once '../includes/sidebar.php';

// UBAH BARIS INI: Sesuaikan dengan yang ada di dashboard.php
// Jika di dashboard pakai 'user_id', maka di sini harus 'user_id' juga
$uid = $_SESSION['user_id'] ?? $_SESSION['id_user']; 

if (!$uid) {
    die("Sesi berakhir, silakan login kembali.");
}

// Query mengambil data lengkap mahasiswa
$query = mysqli_query($conn, "
    SELECT u.nama, u.username, m.nim, m.prodi, m.kontak 
    FROM users u
    JOIN mahasiswa m ON u.id_user = m.id_user
    WHERE u.id_user = '$uid'
");
$user = mysqli_fetch_assoc($query);
?>

<div class="container-fluid px-4">
    <nav aria-label="breadcrumb" class="mt-4">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="dashboard.php" class="text-decoration-none text-secondary">Dashboard</a></li>
            <li class="breadcrumb-item active" aria-current="page">Profile</li>
        </ol>
    </nav>

    <div class="card shadow-sm mb-4 border-0">
        <div class="card-body d-flex align-items-center p-4">
            <div class="me-4 d-none d-sm-block">
                <i class="bi bi-person-circle text-light bg-secondary rounded-circle" style="font-size: 85px; padding: 5px;"></i>
            </div>
            <div>
                <h2 class="fw-bold mb-1" style="letter-spacing: -1px;">
                    <?= $user['nim'] ?> <?= strtoupper($user['nama']) ?>
                </h2>
                <a href="#" class="text-decoration-none text-muted small"><i class="bi bi-chat-left-text-fill"></i> Message</a>
            </div>
            <div class="ms-auto text-end">
                <button class="btn btn-outline-secondary btn-sm border-0"><i class="bi bi-gear-fill fs-5"></i></button>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-8">
            <div class="card shadow-sm mb-4 border-0">
                <div class="card-header bg-white border-bottom py-3 d-flex justify-content-between align-items-center">
                    <h6 class="mb-0 fw-bold">User details</h6>
                    <a href="edit_profil.php" class="small text-decoration-none">Edit profile</a>
                </div>
                <div class="card-body py-4">
                    <div class="mb-4">
                        <label class="fw-bold d-block small text-muted text-uppercase mb-1">Email address</label>
                        <a href="mailto:<?= $user['username'] ?>@students.utdi.ac.id" class="text-decoration-none">
                            <?= htmlspecialchars($user['username']) ?>@students.utdi.ac.id
                        </a>
                        <div class="small text-muted mt-1">(Visible to other course participants)</div>
                    </div>
                    <div class="mb-4">
                        <label class="fw-bold d-block small text-muted text-uppercase mb-1">Program Studi</label>
                        <span class="fs-6"><?= htmlspecialchars($user['prodi'] ?: 'Data belum diisi') ?></span>
                    </div>
                    <div>
                        <label class="fw-bold d-block small text-muted text-uppercase mb-1">Kontak Person</label>
                        <span class="fs-6"><?= htmlspecialchars($user['kontak'] ?: '-') ?></span>
                    </div>
                </div>
            </div>

            <div class="card shadow-sm mb-4 border-0">
                <div class="card-header bg-white border-bottom">
                    <h6 class="mb-0 fw-bold py-1">Privacy and policies</h6>
                </div>
                <div class="card-body">
                    <a href="#" class="small text-decoration-none">Data retention summary</a>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card shadow-sm mb-4 border-0">
                <div class="card-header bg-white border-bottom">
                    <h6 class="mb-0 fw-bold py-1">Miscellaneous</h6>
                </div>
                <div class="card-body">
                    <ul class="list-unstyled mb-0 small">
                        <li class="mb-3"><a href="#" class="text-decoration-none">My certificates</a></li>
                        <li class="mb-3"><a href="data_pinjaman.php" class="text-decoration-none">Forum posts (Aktivitas Pinjam)</a></li>
                        <li class="mb-0"><a href="#" class="text-decoration-none">Learning plans</a></li>
                    </ul>
                </div>
            </div>

            <div class="card shadow-sm border-0">
                <div class="card-header bg-white border-bottom">
                    <h6 class="mb-0 fw-bold py-1">Reports</h6>
                </div>
                <div class="card-body small">
                    <ul class="list-unstyled mb-0">
                        <li class="mb-3"><a href="#" class="text-decoration-none">Browser sessions</a></li>
                        <li class="mb-0"><a href="#" class="text-decoration-none">Grades overview</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>