<?php
// mahasiswa/notifikasi.php

require_once '../config/config.php';
require_once '../config/database.php';
require_once '../config/session.php';

cek_role('mahasiswa');

$uid = $_SESSION['user_id'];

// 1. Logika Tetap: Ambil data notifikasi berdasarkan user yang login
$data = mysqli_query($conn, "
    SELECT pesan, status, created_at
    FROM notifikasi
    WHERE id_user='$uid'
    ORDER BY created_at DESC
");

// 2. Logika Tetap: Tandai semua sebagai dibaca saat halaman dibuka
mysqli_query($conn, "UPDATE notifikasi SET status='dibaca' WHERE id_user='$uid'");

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
?>

<div class="container-fluid px-4 mt-4">
    <div class="d-flex align-items-center mb-4">
        <i class="bi bi-bell-fill text-primary fs-4 me-2"></i>
        <h4 class="mb-0">Notifikasi Perpanjangan</h4>
    </div>

    <?php if (mysqli_num_rows($data) == 0) : ?>
        <div class="card border-0 shadow-sm text-center py-5" style="border-radius: 15px;">
            <div class="card-body">
                <i class="bi bi-mailbox text-muted mb-3" style="font-size: 3rem;"></i>
                <p class="text-muted mb-0">Belum ada notifikasi baru untuk Anda.</p>
            </div>
        </div>
    <?php else : ?>
        <div class="row">
            <div class="col-lg-9 col-md-12">
                <?php while ($r = mysqli_fetch_assoc($data)) : 
                
                    // 3. Logika Tetap: Menentukan ikon berdasarkan isi pesan
                    $is_rejected = (strpos(strtolower($r['pesan']), 'ditolak') !== false);
                    $icon = $is_rejected ? 'bi-x-circle-fill text-danger' : 'bi-check-circle-fill text-success';
                    $border_color = $is_rejected ? 'border-danger' : 'border-success';
                ?>
                    <div class="card mb-3 border-0 border-start border-4 <?= $border_color ?> shadow-sm" style="border-radius: 8px;">
                        <div class="card-body p-3">
                            <div class="d-flex align-items-center">
                                <div class="icon-box me-3">
                                    <i class="bi <?= $icon ?> fs-4"></i>
                                </div>
                                
                                <div class="flex-grow-1">
                                    <p class="mb-1 text-dark fw-medium" style="line-height: 1.4;">
                                        <?= htmlspecialchars($r['pesan']) ?>
                                    </p>
                                    
                                    <div class="d-flex align-items-center text-muted">
                                        <i class="bi bi-clock-history me-1 small"></i> 
                                        <small style="font-size: 0.85rem;">
                                            <?= date('d M Y, H:i', strtotime($r['created_at'])) ?> WIB
                                        </small>
                                    </div>
                                </div>

                                <?php if ($r['status'] == 'belum') : ?>
                                    <span class="badge bg-primary rounded-pill">Baru</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<style>
    .card {
        transition: transform 0.2s ease;
    }
    .card:hover {
        transform: translateX(5px);
    }
    .fw-medium {
        font-weight: 500;
    }
</style>

<?php require_once '../includes/footer.php'; ?>