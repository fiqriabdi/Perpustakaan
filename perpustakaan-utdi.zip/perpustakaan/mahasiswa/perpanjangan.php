<?php
// mahasiswa/perpanjangan.php
// online
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../config/session.php';

cek_role('mahasiswa');

$uid = $_SESSION['user_id'];
$q_mhs = mysqli_query($conn, "SELECT id_mahasiswa FROM mahasiswa WHERE id_user='$uid'");
$m = mysqli_fetch_assoc($q_mhs);
$id_mahasiswa = $m['id_mahasiswa'];

$msg = "";
$status_msg = "success";

if (isset($_POST['ajukan'])) {
    $kode = mysqli_real_escape_string($conn, $_POST['kode_buku']);
    $judul = mysqli_real_escape_string($conn, $_POST['judul_manual']);
    $pengarang = mysqli_real_escape_string($conn, $_POST['pengarang_manual']);
    $ket = mysqli_real_escape_string($conn, $_POST['keterangan']);

    // Validasi Duplikasi: Cek apakah ada pengajuan PENDING untuk buku yang sama
    $cek_duplikat = mysqli_query($conn, "SELECT id_perpanjangan FROM perpanjangan 
                                         WHERE id_mahasiswa = '$id_mahasiswa' 
                                         AND kode_buku = '$kode' 
                                         AND status = 'pending'");

    if (mysqli_num_rows($cek_duplikat) > 0) {
        $msg = "⚠️ Anda sudah mengajukan perpanjangan untuk buku ini. Mohon tunggu verifikasi petugas.";
        $status_msg = "warning";
    } else {
        $query = "INSERT INTO perpanjangan (id_peminjaman, id_mahasiswa, tanggal_request, jenis_pengajuan, kode_buku, judul_manual, pengarang_manual, status, keterangan) 
                  VALUES (NULL, '$id_mahasiswa', CURDATE(), 'manual', '$kode', '$judul', '$pengarang', 'pending', '$ket')";

        if (mysqli_query($conn, $query)) {
            $msg = "Pengajuan manual berhasil dikirim!";
        } else {
            $msg = "Gagal mengirim pengajuan.";
            $status_msg = "danger";
        }
    }
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
?>

<div class="container-fluid px-4 mt-4">
    <h4>Ajukan Perpanjangan Online</h4>
    <?php if($msg): ?> 
        <div class="alert alert-<?= $status_msg ?> alert-dismissible fade show" role="alert">
            <?= $msg ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div> 
    <?php endif; ?>
    
    <div class="card shadow-sm border-0">
        <div class="card-body">
            <form method="POST">
                <div class="mb-3">
                    <label class="fw-bold">Kode Buku / Barcode</label>
                    <input type="text" name="kode_buku" class="form-control" placeholder="Masukkan kode buku" required>
                </div>
                <div class="mb-3">
                    <label class="fw-bold">Judul Buku</label>
                    <input type="text" name="judul_manual" class="form-control" placeholder="Masukkan judul buku" required>
                </div>
                <div class="mb-3">
                    <label class="fw-bold">Pengarang</label>
                    <input type="text" name="pengarang_manual" class="form-control" placeholder="Nama pengarang" required>
                </div>
                <div class="mb-3">
                    <label class="fw-bold">Alasan Perpanjangan</label>
                    <textarea name="keterangan" class="form-control" rows="3" placeholder="Contoh: Buku masih digunakan untuk referensi tugas akhir"></textarea>
                </div>
                <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                    <a href="dashboard.php" class="btn btn-secondary px-4">Kembali</a>
                    <button type="submit" name="ajukan" class="btn btn-primary px-4">Kirim Pengajuan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php require_once '../includes/footer.php'; ?>