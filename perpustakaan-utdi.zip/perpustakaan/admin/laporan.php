<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../modules/peminjaman/peminjaman_controller.php';

cek_role('admin');

$success = '';
if (isset($_GET['action']) && $_GET['action'] == 'kembali') {
    if (prosesPengembalian($conn, $_GET['id'])) {
        $success = "Buku berhasil dikembalikan!";
    }
}

$data = getLaporanPeminjaman($conn);

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
        <h2 class="h3 mb-0 text-gray-800"><i class="bi bi-file-earmark-bar-graph-fill me-2"></i>Laporan Peminjaman</h2>
        <button onclick="window.print()" class="btn btn-success shadow-sm print-hide">
            <i class="bi bi-printer me-1"></i> Cetak PDF/Print
        </button>
    </div>

    <?php if($success): ?>
        <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> <?= $success ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm border-0">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark small text-uppercase">
                        <tr>
                            <th class="px-3 text-center">No</th>
                            <th>NIM</th>
                            <th>Nama Mahasiswa</th>
                            <th>Kode Buku</th>
                            <th>Judul Buku</th>
                            <th>Tgl Pinjam</th>
                            <th class="text-center">Status</th>
                            <th class="text-center print-hide">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1; 
                        while($row = mysqli_fetch_assoc($data)): 
                        ?>
                        <tr>
                            <td class="text-center text-muted"><?= $no++ ?></td>
                            <td class="fw-bold"><?= $row['nim'] ?></td>
                            <td><?= htmlspecialchars($row['nama_mhs']) ?></td>
                            <td><span class="badge bg-light text-dark border"><?= $row['kode_buku'] ?></span></td>
                            <td><?= htmlspecialchars($row['judul']) ?></td>
                            <td>
                                <small class="text-muted d-block">Pinjam: <?= date('d/m/Y', strtotime($row['tanggal_pinjam'])) ?></small>
                                <?php if($row['tanggal_kembali']): ?>
                                    <small class="text-success d-block">Kembali: <?= date('d/m/Y', strtotime($row['tanggal_kembali'])) ?></small>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <?php if($row['status'] == 'dipinjam'): ?>
                                    <span class="badge bg-warning text-dark">Dipinjam</span>
                                <?php elseif($row['status'] == 'dikembalikan'): ?>
                                    <span class="badge bg-success">Dikembalikan</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Terlambat</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center print-hide">
                                <?php if($row['status'] != 'dikembalikan'): ?>
                                    <a href="?action=kembali&id=<?= $row['id_peminjaman'] ?>" 
                                       class="btn btn-sm btn-primary"
                                       onclick="return confirm('Proses buku kembali?')">Selesai</a>
                                <?php else: ?>
                                    <i class="bi bi-check2-circle text-success fs-5"></i>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
@media print {
    .print-hide, .sidebar, .navbar, .btn-close { display: none !important; }
    .container-fluid { width: 100%; margin: 0; padding: 0; }
    .card { border: none !important; box-shadow: none !important; }
    .table-dark { background-color: #fff !important; color: #000 !important; border-bottom: 2px solid #000; }
}
</style>

<?php require_once '../includes/footer.php'; ?>