<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../modules/mahasiswa/mahasiswa_model.php';

cek_role('admin');

$success = $error = '';

// ACTION: TAMBAH
if (isset($_POST['tambah'])) {
    $result = tambahMahasiswa($conn, $_POST);
    if ($result === true) $success = "Mahasiswa berhasil ditambahkan!";
    else $error = $result;
}

// ACTION: UPDATE
if (isset($_POST['update'])) {
    $result = updateMahasiswa($conn, $_POST);
    if ($result === true) $success = "Data berhasil diperbarui.";
    else $error = $result;
}

// ACTION: STATUS (HAPUS/RESTORE)
if (isset($_GET['hapus'])) {
    setStatusMahasiswa($conn, (int)$_GET['hapus'], 'nonaktif');
    $success = "Mahasiswa dinonaktifkan.";
}
if (isset($_GET['restore'])) {
    setStatusMahasiswa($conn, (int)$_GET['restore'], 'aktif');
    $success = "Akun mahasiswa diaktifkan kembali.";
}

// DATA UNTUK TABEL
$query_aktif = getMahasiswaByStatus($conn, 'aktif');
$query_nonaktif = getMahasiswaByStatus($conn, 'nonaktif');

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
        <h2 class="h3 mb-0 text-gray-800"><i class="bi bi-people-fill me-2"></i>Data Mahasiswa</h2>
        <div>
            <button type="button" class="btn btn-primary shadow-sm" data-bs-toggle="modal" data-bs-target="#modalTambah">
                <i class="bi bi-person-plus-fill me-1"></i> Tambah Anggota
            </button>
            <a href="dashboard.php" class="btn btn-outline-secondary shadow-sm ms-2">Kembali</a>
        </div>
    </div>

    <?php if($success): ?>
        <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> <?= $success ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if($error): ?>
        <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="modal fade" id="modalTambah" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Form Tambah Mahasiswa</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="post">
                    <div class="modal-body">
                        <div class="mb-3"><label class="small fw-bold">NIM</label><input type="text" name="nim" class="form-control" required></div>
                        <div class="mb-3"><label class="small fw-bold">NAMA LENGKAP</label><input type="text" name="nama" class="form-control" required></div>
                        <div class="mb-3"><label class="small fw-bold">USERNAME</label><input type="text" name="username" class="form-control" required></div>
                        <div class="mb-3"><label class="small fw-bold">PRODI</label><input type="text" name="prodi" class="form-control"></div>
                        <div class="mb-3"><label class="small fw-bold">KONTAK</label><input type="text" name="kontak" class="form-control"></div>
                        <div class="mb-3"><label class="small fw-bold">PASSWORD</label><input type="password" name="password" class="form-control" required></div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" name="tambah" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small fw-bold">
                        <tr>
                            <th class="px-4">NIM</th>
                            <th>MAHASISWA</th>
                            <th>USERNAME</th>
                            <th>KONTAK</th>
                            <th>AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($query_aktif)): ?>
                        <tr>
                            <td class="px-4 fw-bold text-primary"><?= $row['nim'] ?></td>
                            <td><?= htmlspecialchars($row['nama']) ?><br><small class="text-muted"><?= $row['prodi'] ?></small></td>
                            <td><code class="text-dark"><?= $row['username'] ?></code></td>
                            <td><span class="badge bg-light text-dark border"><?= $row['kontak'] ?: '-' ?></span></td>
                            <td>
                                <a href="?edit=<?= $row['id_user'] ?>" class="btn btn-warning btn-sm"><i class="bi bi-pencil"></i></a>
                                <a href="?hapus=<?= $row['id_user'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Nonaktifkan mahasiswa ini?')"><i class="bi bi-trash"></i></a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <?php if(isset($_GET['edit'])): 
        $id = (int)$_GET['edit'];
        $res = mysqli_query($conn, "SELECT u.*, m.nim, m.prodi, m.kontak FROM users u JOIN mahasiswa m ON u.id_user=m.id_user WHERE u.id_user=$id");
        $edit = mysqli_fetch_assoc($res);
    ?>
    <div class="card border-warning mb-4 shadow-sm">
        <div class="card-header bg-warning fw-bold">Edit Mahasiswa: <?= htmlspecialchars($edit['nama']) ?></div>
        <div class="card-body">
            <form method="post">
                <input type="hidden" name="id_user" value="<?= $edit['id_user'] ?>">
                <div class="row">
                    <div class="col-md-4 mb-3"><label>NIM</label><input type="text" name="nim" class="form-control" value="<?= $edit['nim'] ?>"></div>
                    <div class="col-md-4 mb-3"><label>Nama</label><input type="text" name="nama" class="form-control" value="<?= $edit['nama'] ?>"></div>
                    <div class="col-md-4 mb-3"><label>Username</label><input type="text" name="username" class="form-control" value="<?= $edit['username'] ?>"></div>
                    <div class="col-md-6 mb-3"><label>Prodi</label><input type="text" name="prodi" class="form-control" value="<?= $edit['prodi'] ?>"></div>
                    <div class="col-md-6 mb-3"><label>Kontak</label><input type="text" name="kontak" class="form-control" value="<?= $edit['kontak'] ?>"></div>
                    <div class="col-md-12 mb-3"><label class="text-danger">Password Baru (Kosongkan jika tidak ganti)</label><input type="password" name="password" class="form-control"></div>
                </div>
                <button type="submit" name="update" class="btn btn-primary">Simpan Perubahan</button>
                <a href="kelola_mahasiswa.php" class="btn btn-light border">Batal</a>
            </form>
        </div>
    </div>
    <?php endif; ?>

    <?php if (mysqli_num_rows($query_nonaktif) > 0): ?>
    <div class="card bg-light border-0">
        <div class="card-header py-2 small fw-bold text-secondary">Arsip Non-Aktif (Mahasiswa yang dinonaktifkan)</div>
        <div class="card-body p-0">
            <table class="table table-sm mb-0">
                <?php while ($row_na = mysqli_fetch_assoc($query_nonaktif)): ?>
                <tr>
                    <td class="px-4 text-muted small"><?= $row_na['nim'] ?> - <?= htmlspecialchars($row_na['nama']) ?></td>
                    <td class="text-end px-4"><a href="?restore=<?= $row_na['id_user'] ?>" class="btn btn-link btn-sm text-decoration-none p-0">Aktifkan Kembali</a></td>
                </tr>
                <?php endwhile; ?>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>