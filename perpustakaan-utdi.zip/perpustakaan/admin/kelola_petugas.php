<?php
// admin/kelola_petugas.php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../modules/user/petugas_model.php'; // Pastikan path ini sesuai gambar struktur Anda

cek_role('admin');

$success = $error = '';
$nama = $username = '';

// ==========================================
// HANDLE ACTIONS (TAMBAH, UPDATE, HAPUS)
// ==========================================

// 1. TAMBAH PETUGAS
if (isset($_POST['simpan'])) {
    if (tambahPetugas($conn, $_POST)) {
        $success = "Petugas '" . htmlspecialchars($_POST['nama']) . "' berhasil ditambahkan!";
        $nama = $username = ''; // Reset form setelah berhasil
    } else {
        $error = "Gagal! Username '" . htmlspecialchars($_POST['username']) . "' sudah digunakan.";
    }
}

// 2. EDIT PETUGAS
if (isset($_POST['update'])) {
    if (updatePetugas($conn, $_POST)) {
        $success = "Data petugas '" . htmlspecialchars($_POST['nama']) . "' berhasil diperbarui!";
    } else {
        $error = "Gagal! Username sudah digunakan oleh petugas lain.";
    }
}

// 3. HAPUS PETUGAS (HARD DELETE)
if (isset($_GET['hapus'])) {
    if (hardDeletePetugas($conn, (int)$_GET['hapus'])) {
        $success = "Akun petugas telah dihapus permanen dari database!";
    } else {
        $error = "Gagal menghapus data.";
    }
}

// ==========================================
// PENGAMBILAN DATA UNTUK TAMPILAN
// ==========================================

// Ambil Data Terbaru untuk Tabel
$data = getAllPetugas($conn);

// Cek jika sedang dalam mode EDIT
$is_edit = false;
$edit_data = null;
if (isset($_GET['edit'])) {
    $res_edit = getPetugasById($conn, (int)$_GET['edit']);
    $edit_data = mysqli_fetch_assoc($res_edit);
    if ($edit_data) $is_edit = true;
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
        <h2><i class="bi bi-person-badge-fill me-2"></i>Kelola Petugas</h2>
        <a href="dashboard.php" class="btn btn-secondary btn-sm shadow-sm">
            <i class="bi bi-arrow-left"></i> Dashboard
        </a>
    </div>

    <?php if($success): ?>
        <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> <?= $success ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if($error): ?>
        <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg-4">
            <div class="card shadow-sm border-0 mb-4">
                <div class="card-header <?= $is_edit ? 'bg-warning text-dark' : 'bg-dark text-white' ?> py-3">
                    <h6 class="mb-0 fw-bold">
                        <i class="bi <?= $is_edit ? 'bi-pencil-square' : 'bi-plus-circle' ?> me-2"></i>
                        <?= $is_edit ? 'Edit Petugas' : 'Tambah Petugas Baru' ?>
                    </h6>
                </div>
                <div class="card-body">
                    <form method="post">
                        <?php if($is_edit): ?>
                            <input type="hidden" name="id_user" value="<?= $edit_data['id_user'] ?>">
                        <?php endif; ?>
                        
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted text-uppercase">Nama Lengkap</label>
                            <input type="text" name="nama" class="form-control form-control-lg" placeholder="Masukkan nama petugas" 
                                   value="<?= $is_edit ? htmlspecialchars($edit_data['nama']) : htmlspecialchars($nama) ?>" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-muted text-uppercase">Username</label>
                            <input type="text" name="username" class="form-control" placeholder="Gunakan untuk login" 
                                   value="<?= $is_edit ? htmlspecialchars($edit_data['username']) : htmlspecialchars($username) ?>" required>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label small fw-bold text-danger text-uppercase">
                                <?= $is_edit ? 'Ganti Password (Kosongkan jika tidak)' : 'Password' ?>
                            </label>
                            <input type="password" name="password" class="form-control" <?= $is_edit ? '' : 'required' ?>>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" name="<?= $is_edit ? 'update' : 'simpan' ?>" 
                                    class="btn <?= $is_edit ? 'btn-warning' : 'btn-primary' ?> py-2 fw-bold shadow-sm">
                                <i class="bi bi-save me-2"></i><?= $is_edit ? 'Update Data' : 'Simpan Petugas' ?>
                            </button>
                            <?php if($is_edit): ?>
                                <a href="kelola_petugas.php" class="btn btn-light border py-2">Batal</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white py-3">
                    <h6 class="mb-0 fw-bold"><i class="bi bi-list-stars me-2"></i>Daftar Petugas Perpustakaan</h6>
                </div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover align-middle mb-0">
                            <thead class="table-light small text-uppercase fw-bold">
                                <tr>
                                    <th class="px-4" style="width: 50px;">No</th>
                                    <th>Petugas</th>
                                    <th>Username</th>
                                    <th class="text-center">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                $no = 1;
                                if(mysqli_num_rows($data) > 0):
                                    while ($row = mysqli_fetch_assoc($data)): 
                                ?>
                                <tr>
                                    <td class="px-4 text-muted"><?= $no++ ?></td>
                                    <td>
                                        <div class="fw-bold text-primary"><?= htmlspecialchars($row['nama']) ?></div>
                                        <span class="badge bg-info-subtle text-info border border-info-subtle rounded-pill" style="font-size: 0.7rem;">Status: Petugas Aktif</span>
                                    </td>
                                    <td><code class="text-dark bg-light px-2 py-1 border rounded"><?= htmlspecialchars($row['username']) ?></code></td>
                                    <td class="text-center">
                                        <div class="btn-group">
                                            <a href="?edit=<?= $row['id_user'] ?>" class="btn btn-outline-warning btn-sm" title="Edit">
                                                <i class="bi bi-pencil-square"></i>
                                            </a>
                                            <a href="?hapus=<?= $row['id_user'] ?>" 
                                               class="btn btn-outline-danger btn-sm" 
                                               onclick="return confirm('Hapus petugas ini secara permanen dari database?')" title="Hapus">
                                                <i class="bi bi-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; else: ?>
                                <tr>
                                    <td colspan="4" class="text-center py-4 text-muted">Belum ada data petugas.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>