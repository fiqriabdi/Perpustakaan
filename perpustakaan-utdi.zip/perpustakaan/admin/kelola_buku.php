<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../config/session.php';
cek_role('admin');

require_once '../modules/buku/buku_model.php';

$success = $error = '';

// --- ACTIONS ---
if (isset($_GET['hapus'])) {
    if (deleteBuku($conn, (int)$_GET['hapus'])) {
        $success = "Buku berhasil dihapus permanen.";
    }
}

if (isset($_POST['tambah'])) {
    if (tambahBuku($conn, $_POST)) {
        $success = "Buku baru berhasil disimpan!";
    } else {
        $error = "Gagal! Kode Buku '" . htmlspecialchars($_POST['kode_buku']) . " sudah ada.";
    }
}

if (isset($_POST['update'])) {
    if (updateBuku($conn, $_POST)) {
        $success = "Data buku berhasil diperbarui!";
    }
}

$data = getAllBuku($conn);
$edit = (isset($_GET['edit'])) ? mysqli_fetch_assoc(getBukuById($conn, $_GET['edit'])) : null;

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
        <h2 class="h3 mb-0 text-gray-800">📚 Kelola Inventaris Buku</h2>
    </div>

    <?php if($success): ?>
        <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm" role="alert">
            <i class="bi bi-check-circle-fill me-2"></i> <?= $success ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if($error): ?>
        <div class="alert alert-danger alert-dismissible fade show border-0 shadow-sm" role="alert">
            <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card mb-4 shadow-sm border-0">
        <div class="card-header <?= $edit ? 'bg-warning' : 'bg-primary text-white' ?> py-3">
            <h6 class="mb-0 fw-bold"><i class="bi bi-pencil-square me-2"></i><?= $edit ? 'Edit Informasi Buku' : 'Tambah Koleksi Baru' ?></h6>
        </div>
        <div class="card-body p-4">
            <form method="post">
                <input type="hidden" name="id_buku" value="<?= $edit['id_buku'] ?? '' ?>">
                
                <div class="row g-3 mb-4">
                    <div class="col-md-3">
                        <label class="form-label small fw-bold">KODE BUKU</label>
                        <input type="text" name="kode_buku" class="form-control bg-light" placeholder="Contoh: B001" value="<?= $edit['kode_buku'] ?? '' ?>" required>
                    </div>
                    <div class="col-md-9">
                        <label class="form-label small fw-bold">JUDUL LENGKAP</label>
                        <input type="text" name="judul" class="form-control" placeholder="Masukkan judul buku" value="<?= $edit['judul'] ?? '' ?>" required>
                    </div>
                </div>

                <div class="row g-3 mb-4">
                    <div class="col-md-4">
                        <label class="form-label small fw-bold">PENGARANG</label>
                        <input type="text" name="pengarang" class="form-control" value="<?= $edit['pengarang'] ?? '' ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-bold">PENERBIT</label>
                        <input type="text" name="penerbit" class="form-control" value="<?= $edit['penerbit'] ?? '' ?>">
                    </div>
                    <div class="col-md-2">
                        <label class="form-label small fw-bold">TAHUN</label>
                        <input type="number" name="tahun" class="form-control" placeholder="YYYY" value="<?= $edit['tahun'] ?? '' ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-bold">STOK (JUMLAH)</label>
                        <div class="input-group">
                            <input type="number" name="stok" class="form-control" value="<?= $edit['stok'] ?? '0' ?>" required min="0">
                            <span class="input-group-text bg-light small text-muted">Buku</span>
                        </div>
                    </div>
                </div>

                <div class="text-end">
                    <?php if($edit): ?>
                        <a href="kelola_buku.php" class="btn btn-outline-secondary px-4">Batal</a>
                        <button type="submit" name="update" class="btn btn-warning px-4 shadow-sm">Update Data</button>
                    <?php else: ?>
                        <button type="submit" name="tambah" class="btn btn-primary px-4 shadow-sm">Simpan Koleksi</button>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <div class="card shadow-sm border-0">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small fw-bold">
                        <tr>
                            <th class="px-4 py-3" width="150">KODE</th>
                            <th>JUDUL & PENGARANG</th>
                            <th class="text-center">STOK</th>
                            <th class="text-center" width="150">AKSI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($b = mysqli_fetch_assoc($data)): ?>
                        <tr>
                            <td class="px-4"><code><?= $b['kode_buku'] ?></code></td>
                            <td>
                                <div class="fw-bold text-dark"><?= htmlspecialchars($b['judul']) ?></div>
                                <div class="small text-muted"><i class="bi bi-person me-1"></i><?= htmlspecialchars($b['pengarang'] ?: '-') ?></div>
                            </td>
                            <td class="text-center">
                                <span class="badge <?= $b['stok'] < 3 ? 'bg-danger' : 'bg-success' ?> rounded-pill px-3">
                                    <?= $b['stok'] ?>
                                </span>
                            </td>
                            <td class="text-center">
                                <div class="btn-group">
                                    <a href="?edit=<?= $b['id_buku'] ?>" class="btn btn-sm btn-outline-warning"><i class="bi bi-pencil"></i></a>
                                    <a href="?hapus=<?= $b['id_buku'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Hapus buku ini secara permanen?')"><i class="bi bi-trash"></i></a>
                                </div>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>