<?php
// petugas/verifikasi_perpanjangan.php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../config/session.php';
require_once '../modules/notifikasi/notifikasi.php';

cek_role('petugas');

if (isset($_GET['action'], $_GET['id'])) {
    $id = (int)$_GET['id'];
    $action = $_GET['action'];

    // 1. Ambil data request dan ID User mahasiswa
    $q_req = mysqli_query($conn, "SELECT p.*, m.id_user, m.nama 
                                  FROM perpanjangan p 
                                  JOIN mahasiswa m ON p.id_mahasiswa = m.id_mahasiswa 
                                  WHERE p.id_perpanjangan = '$id'");
    $d = mysqli_fetch_assoc($q_req);

    if (!$d) {
        header("Location: verifikasi_perpanjangan.php");
        exit;
    }

    $id_user_mhs = $d['id_user'];
    $id_mhs      = $d['id_mahasiswa'];
    $judul_buku  = $d['judul_manual'];
    $hari        = 7; // Durasi default perpanjangan
    $pesan_notif = "";
    $id_b_real   = 0;

    if ($action === 'accept') {
        // A. Update status request jadi accept
        mysqli_query($conn, "UPDATE perpanjangan SET status='accept' WHERE id_perpanjangan='$id'");

        // B. Cari transaksi peminjaman aktif
        $kode_buku_req = $d['kode_buku'];
        $q_buku = mysqli_query($conn, "SELECT id_buku FROM buku WHERE kode_buku = '$kode_buku_req'");
        $buku   = mysqli_fetch_assoc($q_buku);

        if ($buku) {
            $id_b_real = $buku['id_buku'];
            $q_pinjam  = mysqli_query($conn, "SELECT id_peminjaman FROM peminjaman 
                                              WHERE id_mahasiswa = '$id_mhs' 
                                              AND id_buku = '$id_b_real' 
                                              AND status = 'dipinjam' LIMIT 1");
            
            if ($p = mysqli_fetch_assoc($q_pinjam)) {
                // Update jatuh tempo +7 hari
                mysqli_query($conn, "UPDATE peminjaman 
                                     SET tanggal_jatuh_tempo = DATE_ADD(tanggal_jatuh_tempo, INTERVAL $hari DAY) 
                                     WHERE id_peminjaman = '{$p['id_peminjaman']}'");
                
                $pesan_notif = "Buku \"$judul_buku\" diperpanjang oleh petugas (+$hari hari).";
                
                // C. Catat ke log_perpanjangan (Jika tabel tersedia)
                mysqli_query($conn, "INSERT INTO log_perpanjangan 
                    (id_perpanjangan, id_buku, id_mahasiswa, tanggal_perpanjangan, aksi, status, keterangan)
                    VALUES ('$id', '$id_b_real', '$id_mhs', CURDATE(), 'setujui', 'accept', 'Ditambah $hari hari oleh petugas')");
            } else {
                $pesan_notif = "Request disetujui, tapi sistem gagal mencocokkan data transaksi aktif.";
            }
        }
    } else if ($action === 'reject') {
        // Update status request jadi reject
        mysqli_query($conn, "UPDATE perpanjangan SET status='reject' WHERE id_perpanjangan='$id'");
        $pesan_notif = "Perpanjangan buku \"$judul_buku\" ditolak oleh petugas.";
    }

    // 2. Masukkan Notifikasi ke Mahasiswa
    if (!empty($pesan_notif)) {
        $pesan_db = mysqli_real_escape_string($conn, $pesan_notif);
        mysqli_query($conn, "INSERT INTO notifikasi (id_user, pesan, status, created_at) 
                             VALUES ('$id_user_mhs', '$pesan_db', 'belum', NOW())");
    }

    header("Location: verifikasi_perpanjangan.php?msg=success");
    exit;
}

// Tampilkan daftar pending
$data = mysqli_query($conn, "SELECT p.*, m.nim, m.nama FROM perpanjangan p
                             JOIN mahasiswa m ON p.id_mahasiswa = m.id_mahasiswa
                             WHERE p.status='pending' ORDER BY p.tanggal_request DESC");

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
?>

<div class="container-fluid px-4 mt-4">
    <h4 class="mb-4">Verifikasi Perpanjangan</h4>
    <div class="card shadow-sm border-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th width="5%">No</th>
                        <th>Mahasiswa</th>
                        <th>Info Buku</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no=1; 
                    if(mysqli_num_rows($data) > 0):
                        while($row = mysqli_fetch_assoc($data)): 
                    ?>
                    <tr>
                        <td><?= $no++ ?></td>
                        <td>
                            <strong><?= htmlspecialchars($row['nama']) ?></strong><br>
                            <small class="text-muted"><?= $row['nim'] ?></small>
                        </td>
                        <td>
                            <span class="badge bg-secondary mb-1"><?= $row['kode_buku'] ?></span><br>
                            <?= htmlspecialchars($row['judul_manual']) ?>
                        </td>
                        <td class="text-center">
                            <a href="?action=accept&id=<?= $row['id_perpanjangan'] ?>" class="btn btn-success btn-sm" title="Setujui">
                                <i class="bi bi-check-lg"></i>
                            </a>
                            <a href="?action=reject&id=<?= $row['id_perpanjangan'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tolak perpanjangan ini?')" title="Tolak">
                                <i class="bi bi-x-lg"></i>
                            </a>
                        </td>
                    </tr>
                    <?php 
                        endwhile; 
                    else: 
                    ?>
                    <tr>
                        <td colspan="4" class="text-center py-4 text-muted">Tidak ada antrean perpanjangan.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>