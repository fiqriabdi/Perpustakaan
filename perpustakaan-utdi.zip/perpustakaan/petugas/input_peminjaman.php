<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../config/session.php';

// Proteksi Role
cek_role('petugas');

$success = $error = '';

if (isset($_POST['simpan'])) {
    $nim     = mysqli_real_escape_string($conn, $_POST['nim']);
    $id_buku = mysqli_real_escape_string($conn, $_POST['id_buku']);

    // 1. CARI MAHASISWA & CEK STATUS AKUN
    $mhs_query = mysqli_query($conn, "
        SELECT m.id_mahasiswa, m.nama FROM mahasiswa m 
        JOIN users u ON m.id_user = u.id_user 
        WHERE m.nim='$nim' AND u.status='aktif'
    ");

    if (mysqli_num_rows($mhs_query) == 0) {
        $error = "Mahasiswa tidak ditemukan atau akun sedang dinonaktifkan.";
    } else {
        $m = mysqli_fetch_assoc($mhs_query);
        $id_mahasiswa = $m['id_mahasiswa'];
        $nama_mhs     = $m['nama'];

        // 2. CEK LIMIT PEMINJAMAN (Maksimal 3 buku yang belum dikembalikan)
        $cek_limit = mysqli_query($conn, "SELECT COUNT(*) as total FROM peminjaman WHERE id_mahasiswa='$id_mahasiswa' AND status='dipinjam'");
        $limit = mysqli_fetch_assoc($cek_limit);

        if ($limit['total'] >= 3) {
            $error = "Gagal! <strong>$nama_mhs</strong> masih memiliki 3 buku yang belum dikembalikan.";
        } else {
            // 3. CEK BUKU & STOK
            $cekBuku = mysqli_query($conn, "SELECT stok, judul FROM buku WHERE id_buku='$id_buku' AND status='aktif'");
            $buku = mysqli_fetch_assoc($cekBuku);

            if (!$buku || $buku['stok'] <= 0) {
                $error = "Buku tidak tersedia atau stok habis.";
            } else {
                // 4. PROSES INSERT DENGAN TRANSAKSI
                $judul_buku  = $buku['judul'];
                $tgl_pinjam  = date('Y-m-d');
                $jatuh_tempo = date('Y-m-d', strtotime('+7 days'));
                $uid_petugas = $_SESSION['user_id'];

                mysqli_begin_transaction($conn);

                try {
                    // Simpan data peminjaman
                    mysqli_query($conn, "INSERT INTO peminjaman (id_mahasiswa, id_buku, tanggal_pinjam, tanggal_jatuh_tempo, status) 
                                         VALUES ('$id_mahasiswa', '$id_buku', '$tgl_pinjam', '$jatuh_tempo', 'dipinjam')");

                    // Kurangi stok buku
                    mysqli_query($conn, "UPDATE buku SET stok = stok - 1 WHERE id_buku='$id_buku'");

                    // Catat Log
                    mysqli_query($conn, "INSERT INTO log_aktivitas (id_user, aktivitas) 
                                         VALUES ('$uid_petugas', 'Input pinjam: $judul_buku untuk NIM: $nim')");

                    mysqli_commit($conn);
                    $success = "Berhasil! Buku wajib dikembalikan paling lambat " . date('d/m/Y', strtotime($jatuh_tempo));
                } catch (Exception $e) {
                    mysqli_rollback($conn);
                    $error = "Terjadi kesalahan sistem saat menyimpan data.";
                }
            }
        }
    }
}

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center mt-4 mb-4">
        <h4><i class="bi bi-journal-plus me-2"></i>Transaksi Peminjaman</h4>
        <a href="data_peminjaman.php" class="btn btn-outline-primary btn-sm">
            <i class="bi bi-table me-1"></i> Lihat Semua Data
        </a>
    </div>

    <div class="row">
        <div class="col-lg-7">
            <?php if ($success) : ?>
                <div class="alert alert-success border-0 shadow-sm mb-4">✅ <?= $success ?></div>
            <?php endif; ?>

            <?php if ($error) : ?>
                <div class="alert alert-danger border-0 shadow-sm mb-4">❌ <?= $error ?></div>
            <?php endif; ?>

            <div class="card shadow-sm border-0">
                <div class="card-body p-4">
                    <form method="post">
                        <div class="mb-4">
                            <label class="form-label fw-bold">NIM Mahasiswa</label>
                            <input type="text" name="nim" class="form-control form-control-lg" placeholder="Contoh: 175410097" required autofocus>
                            <div class="form-text text-muted">Pastikan NIM sudah terdaftar di sistem.</div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label fw-bold">Judul Buku</label>
                            <select name="id_buku" class="form-select select2" required>
                                <option value="">-- Cari & Pilih Judul Buku --</option>
                                <?php
                                $buku_res = mysqli_query($conn, "SELECT id_buku, judul, stok FROM buku WHERE status='aktif' AND stok > 0 ORDER BY judul ASC");
                                while ($b = mysqli_fetch_assoc($buku_res)) {
                                    echo "<option value='{$b['id_buku']}'>{$b['judul']} (Tersedia: {$b['stok']})</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="card bg-light border-0 mb-4">
                            <div class="card-body py-2 px-3 small">
                                <i class="bi bi-calendar-event me-2"></i>Durasi Pinjam: <strong>7 Hari</strong>
                            </div>
                        </div>

                        <button type="submit" name="simpan" class="btn btn-primary btn-lg w-100 shadow-sm">
                            <i class="bi bi-check-circle me-1"></i> Simpan Transaksi
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-5">
            <div class="card border-0 shadow-sm h-100 bg-dark text-white">
                <div class="card-body">
                    <h5 class="mb-3">Informasi Penting</h5>
                    <ul class="list-unstyled">
                        <li class="mb-3"><i class="bi bi-info-circle text-warning me-2"></i>Mahasiswa hanya bisa meminjam maksimal <strong>3 buku</strong> secara bersamaan.</li>
                        <li class="mb-3"><i class="bi bi-info-circle text-warning me-2"></i>Buku yang tidak memiliki stok (0) tidak akan muncul dalam daftar pilihan.</li>
                        <li class="mb-3"><i class="bi bi-info-circle text-warning me-2"></i>Sistem secara otomatis menghitung tanggal jatuh tempo 7 hari dari hari ini.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>