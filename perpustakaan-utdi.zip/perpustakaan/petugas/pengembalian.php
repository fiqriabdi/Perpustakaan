<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../config/session.php';

cek_role('petugas');

$success = $error = '';
$tarif_denda = 1000; // Pengaturan denda Rp 1.000 per hari

/* ===============================
   PROSES PENGEMBALIAN & DENDA
   =============================== */
if (isset($_GET['id'])) {
    $id_peminjaman = (int) $_GET['id'];

    // Ambil data peminjaman untuk validasi dan hitung denda
    $query_cek = mysqli_query($conn, "SELECT id_buku, tanggal_jatuh_tempo FROM peminjaman WHERE id_peminjaman='$id_peminjaman' AND status='dipinjam'");

    if (mysqli_num_rows($query_cek) == 1) {
        $data_pj = mysqli_fetch_assoc($query_cek);
        $id_buku = $data_pj['id_buku'];
        $tgl_jatuh_tempo = $data_pj['tanggal_jatuh_tempo'];
        $tgl_kembali = date('Y-m-d');

        // LOGIKA HITUNG DENDA
        $denda = 0;
        $tgl1 = new DateTime($tgl_jatuh_tempo);
        $tgl2 = new DateTime($tgl_kembali);
        
        if ($tgl2 > $tgl1) {
            $selisih = $tgl1->diff($tgl2);
            $hari_terlambat = $selisih->days;
            $denda = $hari_terlambat * $tarif_denda;
        }

        // Mulai Transaksi Database
        mysqli_begin_transaction($conn);
        try {
            // 1. Update status, tanggal kembali, dan nominal denda
            mysqli_query($conn, "UPDATE peminjaman SET 
                status='dikembalikan', 
                tanggal_kembali='$tgl_kembali', 
                denda='$denda' 
                WHERE id_peminjaman='$id_peminjaman'");

            // 2. Tambah kembali stok buku
            mysqli_query($conn, "UPDATE buku SET stok = stok + 1 WHERE id_buku='$id_buku'");

            // 3. Catat Log
            $uid = $_SESSION['user_id'];
            mysqli_query($conn, "INSERT INTO log_aktivitas (id_user, aktivitas) VALUES ('$uid', 'Proses kembali buku ID: $id_buku dengan denda Rp $denda')");

            mysqli_commit($conn);
            
            $msg = "Buku berhasil dikembalikan.";
            if($denda > 0) {
                $msg .= " Mahasiswa terlambat $hari_terlambat hari. <strong>Denda: Rp " . number_format($denda, 0, ',', '.') . "</strong>";
            } else {
                $msg .= " Pengembalian tepat waktu.";
            }
            $success = $msg;

        } catch (Exception $e) {
            mysqli_rollback($conn);
            $error = "Gagal memproses pengembalian: " . $e->getMessage();
        }
    } else {
        $error = "Data peminjaman tidak ditemukan atau sudah dikembalikan.";
    }
}

/* ===============================
   DATA ANTRIAN PENGEMBALIAN
   =============================== */
$data_aktif = mysqli_query($conn, "
    SELECT p.id_peminjaman, m.nim, m.nama, b.kode_buku, b.judul, p.tanggal_pinjam, p.tanggal_jatuh_tempo
    FROM peminjaman p
    JOIN mahasiswa m ON p.id_mahasiswa = m.id_mahasiswa
    JOIN buku b ON p.id_buku = b.id_buku
    WHERE p.status='dipinjam'
    ORDER BY p.tanggal_jatuh_tempo ASC
");

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
?>

<div class="container-fluid px-4 mt-4">
    <h4 class="mb-4">📦 Pengembalian & Hitung Denda</h4>

    <?php if ($success) : ?>
        <div class="alert alert-success shadow-sm border-0 alert-dismissible fade show">
            <i class="bi bi-check-circle-fill me-2"></i> <?= $success ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error) : ?>
        <div class="alert alert-danger shadow-sm border-0 alert-dismissible fade show">
            <i class="bi bi-exclamation-triangle-fill me-2"></i> <?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="card shadow-sm border-0">
        <div class="card-header bg-white fw-bold">Daftar Buku Yang Belum Kembali</div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small text-uppercase">
                        <tr>
                            <th class="text-center">No</th>
                            <th>Peminjam</th>
                            <th>Kode Buku</th>
                            <th>Buku</th>
                            <th class="text-center">Jatuh Tempo</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $no = 1;
                        if (mysqli_num_rows($data_aktif) > 0) :
                            while ($row = mysqli_fetch_assoc($data_aktif)) :
                                $is_late = (date('Y-m-d') > $row['tanggal_jatuh_tempo']);
                        ?>
                        <tr>
                            <td class="text-center text-muted"><?= $no++ ?></td>
                            <td>
                                <strong><?= htmlspecialchars($row['nama']) ?></strong><br>
                                <small class="text-muted"><?= $row['nim'] ?></small>
                            </td>

                            <td><?= htmlspecialchars($row['kode_buku']) ?></td>
                            <td><?= htmlspecialchars($row['judul']) ?></td>
                            <td class="text-center">
                                <span class="badge <?= $is_late ? 'bg-danger' : 'bg-info text-dark' ?>">
                                    <?= date('d/m/Y', strtotime($row['tanggal_jatuh_tempo'])) ?>
                                </span>
                            </td>
                            <td class="text-center">
                                <?php if ($is_late) : 
                                    $t1 = new DateTime($row['tanggal_jatuh_tempo']);
                                    $t2 = new DateTime(date('Y-m-d'));
                                    $diff = $t1->diff($t2)->days;
                                ?>
                                    <small class="text-danger fw-bold">Terlambat <?= $diff ?> Hari</small>
                                <?php else : ?>
                                    <small class="text-success">Masih Berjalan</small>
                                <?php endif; ?>
                            </td>
                            <td class="text-center">
                                <a href="?id=<?= $row['id_peminjaman'] ?>" 
                                   class="btn btn-success btn-sm px-3"
                                   onclick="return confirm('Proses pengembalian buku ini?')">
                                   Kembalikan
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; else: ?>
                        <tr>
                            <td colspan="6" class="text-center py-5 text-muted">Tidak ada peminjaman aktif.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>