

<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../config/session.php';

// Pastikan hanya petugas yang bisa mengakses
cek_role('petugas');

// Pengaturan Header agar file diunduh sebagai Excel
header("Content-type: application/vnd-ms-excel");
header("Content-Disposition: attachment; filename=Laporan_Perpanjangan_".date('d-m-Y').".xls");
header("Pragma: no-cache");
header("Expires: 0");

/* ===============================
   DATA RIWAYAT PERPANJANGAN
   =============================== */
$data = mysqli_query($conn, "
    SELECT 
        p.id_perpanjangan,
        m.nim,
        m.nama,
        b.kode_buku,
        b.judul,
        p.tanggal_request,
        p.status,
        p.jenis_pengajuan
    FROM perpanjangan p
    LEFT JOIN peminjaman pj ON p.id_peminjaman = pj.id_peminjaman
    LEFT JOIN mahasiswa m ON (pj.id_mahasiswa = m.id_mahasiswa OR p.id_mahasiswa = m.id_mahasiswa)
    LEFT JOIN buku b ON (pj.id_buku = b.id_buku OR b.kode_buku = p.kode_buku)
    WHERE p.status IN ('accept','reject')
    GROUP BY p.id_perpanjangan
    ORDER BY p.tanggal_request DESC
");
?>

<style>
    .str { mso-number-format:\@; } /* Format agar angka panjang tidak berubah di Excel */
</style>

<center>
    <h2>LAPORAN RIWAYAT PERPANJANGAN BUKU</h2>
    <p>Dicetak pada tanggal: <?= date('d M Y, H:i') ?></p>
</center>

<table border="1">
    <thead>
        <tr style="background-color: #2c3e50; color: white;">
            <th>No</th>
            <th>NIM</th>
            <th>Nama Mahasiswa</th>
            <th>Kode Buku</th>
            <th>Judul Buku</th>
            <th>Tanggal Request</th>
            <th>Metode</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $no = 1;
        while($row = mysqli_fetch_assoc($data)): 
        ?>
        <tr>
            <td align="center"><?= $no++ ?></td>
            <td class="str"><?= $row['nim'] ?></td>
            <td><?= strtoupper($row['nama']) ?></td>
            <td><?= $row['kode_buku'] ?></td>
            <td><?= $row['judul'] ?></td>
            <td><?= date('d/m/Y', strtotime($row['tanggal_request'])) ?></td>
            <td align="center"><?= ucfirst($row['jenis_pengajuan']) ?></td>
            <td align="center">
                <?= ($row['status'] == 'accept') ? 'DISETUJUI' : 'DITOLAK' ?>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>