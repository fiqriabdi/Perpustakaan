<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../config/session.php';

cek_role('petugas');

/* ===============================
   DATA PEMINJAMAN
   =============================== */
// Query ditingkatkan untuk mengambil data terbaru di atas
$data = mysqli_query($conn, "
    SELECT 
        pj.id_peminjaman,
        m.nim,
        m.nama,
        b.judul,
        b.kode_buku,
        pj.tanggal_pinjam,
        pj.tanggal_jatuh_tempo,
        pj.tanggal_kembali,
        pj.status
    FROM peminjaman pj
    JOIN mahasiswa m ON pj.id_mahasiswa = m.id_mahasiswa
    JOIN buku b ON pj.id_buku = b.id_buku
    ORDER BY pj.status ASC, pj.tanggal_pinjam DESC
");

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center">
        <h4 class="mt-4 mb-4">Data Peminjaman Buku</h4>
        <a href="input_peminjaman.php" class="btn btn-primary btn-sm">
            <i class="bi bi-plus-circle"></i> Tambah Pinjaman Baru
        </a>
    </div>

    <div class="card shadow border-0">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover align-middle">
                    <thead class="table-dark text-center">
                        <tr>
                            <th>No</th>
                            <th>Mahasiswa</th>
                            <th>Buku</th>
                            <th>Tgl Pinjam</th>
                            <th>Jatuh Tempo</th>
                            <th>Tgl Kembali</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $no = 1;
                    if (mysqli_num_rows($data) > 0):
                        while ($row = mysqli_fetch_assoc($data)):
                            // Logika Tambahan: Jika sudah lewat jatuh tempo tapi belum kembali, beri warna khusus
                            $hari_ini = date('Y-m-d');
                            $is_terlambat = ($hari_ini > $row['tanggal_jatuh_tempo'] && $row['status'] == 'dipinjam');
                    ?>
                        <tr>
                            <td class="text-center"><?= $no++ ?></td>
                            <td>
                                <strong><?= htmlspecialchars($row['nama']) ?></strong><br>
                                <small class="text-muted"><?= htmlspecialchars($row['nim']) ?></small>
                            </td>
                            <td>
                                <?= htmlspecialchars($row['judul']) ?><br>
                                <small class="badge bg-light text-dark border"><?= htmlspecialchars($row['kode_buku']) ?></small>
                            </td>
                            <td class="text-center"><?= date('d/m/Y', strtotime($row['tanggal_pinjam'])) ?></td>
                            <td class="text-center"><?= date('d/m/Y', strtotime($row['tanggal_jatuh_tempo'])) ?></td>
                            <td class="text-center">
                                <?= $row['tanggal_kembali'] ? date('d/m/Y', strtotime($row['tanggal_kembali'])) : '<span class="text-muted">-</span>' ?>
                            </td>
                            <td class="text-center">
                                <?php if ($row['status'] == 'dipinjam'): ?>
                                    <?php if ($is_terlambat): ?>
                                        <span class="badge bg-danger">Terlambat</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Dipinjam</span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="badge bg-primary">Dikembalikan</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; else: ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted py-4">
                                Tidak ada data peminjaman ditemukan.
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <a href="dashboard.php" class="btn btn-secondary mt-3">
                <i class="bi bi-arrow-left"></i> Kembali ke Dashboard
            </a>
        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>