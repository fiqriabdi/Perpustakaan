<?php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../config/session.php';

cek_role('petugas');

/* ===============================
   DATA RIWAYAT PERPANJANGAN (FIXED)
   =============================== */
// Kita menggunakan JOIN ke tabel buku karena data asli ada di sana,
// bukan di tabel perpanjangan (kecuali untuk input manual mahasiswa)
$data = mysqli_query($conn, "
    SELECT 
        p.id_perpanjangan,
        m.nim,
        m.nama,
        b.kode_buku,
        b.judul,
        b.pengarang,
        p.tanggal_request,
        p.status,
        p.jenis_pengajuan
    FROM perpanjangan p
    JOIN peminjaman pj ON p.id_peminjaman = pj.id_peminjaman
    JOIN mahasiswa m ON pj.id_mahasiswa = m.id_mahasiswa
    JOIN buku b ON pj.id_buku = b.id_buku
    WHERE p.status IN ('accept','reject')
    ORDER BY p.tanggal_request DESC
");

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
?>

<div class="container-fluid px-4">
    <div class="d-flex justify-content-between align-items-center">
        <h4 class="mt-4 mb-4"><i class="bi bi-clock-history me-2"></i>Riwayat Perpanjangan</h4>
        <span class="badge bg-primary">Total: <?= mysqli_num_rows($data) ?> Data</span>
    </div>

    <div class="card shadow border-0">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-dark text-center">
                        <tr>
                            <th width="50">No</th>
                            <th>Mahasiswa</th>
                            <th>Buku</th>
                            <th>Tanggal Request</th>
                            <th>Metode</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>

                    <?php
                    $no = 1;
                    if (mysqli_num_rows($data) > 0):
                        while ($row = mysqli_fetch_assoc($data)):
                    ?>
                        <tr>
                            <td class="text-center"><?= $no++ ?></td>
                            <td>
                                <strong><?= htmlspecialchars($row['nama']) ?></strong><br>
                                <small class="text-muted"><?= htmlspecialchars($row['nim']) ?></small>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($row['judul']) ?></strong><br>
                                <small class="text-muted">Kode: <?= htmlspecialchars($row['kode_buku']) ?></small>
                            </td>
                            <td class="text-center">
                                <?= date('d M Y', strtotime($row['tanggal_request'])) ?>
                            </td>
                            <td class="text-center">
                                <span class="badge border text-dark bg-light">
                                    <?= ucfirst($row['jenis_pengajuan']) ?>
                                </span>
                            </td>
                            <td class="text-center">
                                <?php if ($row['status'] === 'accept'): ?>
                                    <span class="badge bg-success shadow-sm">
                                        <i class="bi bi-check-circle me-1"></i> Disetujui
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-danger shadow-sm">
                                        <i class="bi bi-x-circle me-1"></i> Ditolak
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; else: ?>
                        <tr>
                            <td colspan="6" class="text-center py-4 text-muted">
                                <i class="bi bi-info-circle me-2"></i> Belum ada riwayat perpanjangan yang diproses.
                            </td>
                        </tr>
                    <?php endif; ?>

                    </tbody>
                </table>
            </div>

            <div class="mt-3">
                <a href="dashboard.php" class="btn btn-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Dashboard
                </a>
                
                <a href="export_riwayat.php" class="btn btn-success float-end">
    <i class="bi bi-file-earmark-excel me-1"></i> Export ke Excel
</a>
    
                </button>
            </div>

        </div>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>