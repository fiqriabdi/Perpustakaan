<?php
// petugas/perpanjangan_manual.php
require_once '../config/config.php';
require_once '../config/database.php';
require_once '../config/session.php';

cek_role('petugas');

$success = $error = '';

/* ======================================================
   PROSES PERPANJANGAN (LOGIKA TRANSAKSI)
   ====================================================== */
if (isset($_POST['perpanjang'])) {
    $id_peminjaman = (int)$_POST['id_peminjaman'];
    $hari          = (int)$_POST['hari'];
    if ($hari <= 0) $hari = 7;

    // Ambil detail data untuk sinkronisasi tabel
    $q = mysqli_query($conn, "
        SELECT pj.id_peminjaman, pj.id_buku, pj.tanggal_jatuh_tempo, b.judul, u.id_user, m.nama, m.id_mahasiswa
        FROM peminjaman pj
        JOIN buku b ON pj.id_buku = b.id_buku
        JOIN mahasiswa m ON pj.id_mahasiswa = m.id_mahasiswa
        JOIN users u ON m.id_user = u.id_user
        WHERE pj.id_peminjaman = '$id_peminjaman' AND pj.status = 'dipinjam'
    ");

    if (mysqli_num_rows($q) == 0) {
        $error = "❌ Data peminjaman tidak valid. Pastikan Anda memilih dari daftar yang tersedia.";
    } else {
        $d = mysqli_fetch_assoc($q);
        $id_user_mhs = $d['id_user'];
        $id_mhs      = $d['id_mahasiswa'];
        $id_buku     = $d['id_buku'];
        $judul_buku  = $d['judul'];
        $uid_petugas = $_SESSION['user_id'];

        mysqli_begin_transaction($conn);

        try {
            // 1. Simpan ke tabel perpanjangan
            mysqli_query($conn, "INSERT INTO perpanjangan 
                (id_peminjaman, tanggal_request, jenis_pengajuan, status, keterangan) 
                VALUES ('$id_peminjaman', CURDATE(), 'manual', 'accept', 'Perpanjangan langsung oleh petugas')");
            $id_perpanjangan = mysqli_insert_id($conn);

            // 2. Update jatuh tempo di tabel peminjaman
            mysqli_query($conn, "UPDATE peminjaman 
                SET tanggal_jatuh_tempo = DATE_ADD(tanggal_jatuh_tempo, INTERVAL $hari DAY) 
                WHERE id_peminjaman = '$id_peminjaman'");

            // 3. Notifikasi untuk mahasiswa
            $pesan_teks = "Buku $judul_buku diperpanjang oleh petugas (+$hari hari)";
            $pesan_db   = mysqli_real_escape_string($conn, $pesan_teks);
            mysqli_query($conn, "INSERT INTO notifikasi (id_user, pesan, status) 
                VALUES ('$id_user_mhs', '$pesan_db', 'belum_dibaca')");

            // 4. Catat ke log_perpanjangan (Pastikan tabel ini ada)
            mysqli_query($conn, "INSERT INTO log_perpanjangan 
                (id_perpanjangan, id_buku, id_mahasiswa, tanggal_perpanjangan, aksi, status, keterangan)
                VALUES ('$id_perpanjangan', '$id_buku', '$id_mhs', CURDATE(), 'setujui', 'accept', 'Ditambah $hari hari oleh petugas')");

            // 5. Log aktivitas umum
            $aktivitas = mysqli_real_escape_string($conn, "Perpanjangan manual buku $judul_buku (ID: $id_peminjaman)");
            mysqli_query($conn, "INSERT INTO log_aktivitas (id_user, aktivitas) 
                VALUES ('$uid_petugas', '$aktivitas')");

            mysqli_commit($conn);
            $success = "✅ Berhasil memperpanjang buku <strong>" . htmlspecialchars($judul_buku) . "</strong>.";
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $error = "❌ Terjadi kesalahan: " . $e->getMessage();
        }
    }
}

/* ======================================================
   DATA PEMINJAMAN UNTUK DATALIST
   ====================================================== */
$data_pinjam = mysqli_query($conn, "
    SELECT 
        pj.id_peminjaman, 
        m.nim, 
        m.nama, 
        b.judul, 
        b.kode_buku,
        pj.tanggal_jatuh_tempo
    FROM peminjaman pj
    JOIN mahasiswa m ON pj.id_mahasiswa = m.id_mahasiswa
    JOIN buku b ON pj.id_buku = b.id_buku
    WHERE pj.status = 'dipinjam'
    ORDER BY pj.tanggal_jatuh_tempo ASC
");

require_once '../includes/header.php';
require_once '../includes/sidebar.php';
?>

<div class="container-fluid px-4 mt-4">
    <h4 class="mb-4 text-dark"><i class="bi bi-calendar-plus me-2"></i>Perpanjangan Manual</h4>

    <?php if ($success) : ?>
        <div class="alert alert-success border-0 shadow-sm alert-dismissible fade show">
            <?= $success ?>
            <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if ($error) : ?>
        <div class="alert alert-danger border-0 shadow-sm alert-dismissible fade show">
            <?= $error ?>
            <button class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-lg-7">
            <div class="card shadow-sm border-0">
                <div class="card-header bg-white py-3">
                    <h6 class="m-0 fw-bold text-primary">Form Perpanjangan Langsung</h6>
                </div>
                <div class="card-body p-4">
                    <form method="post" id="formPerpanjangan">
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-uppercase">Cari Mahasiswa atau Buku</label>
                            <input type="text" id="pencarian" class="form-control border-2" list="list_pinjaman" placeholder="Ketik NIM atau Judul Buku..." autocomplete="off" required>
                            
                            <datalist id="list_pinjaman">
                                <?php while ($r = mysqli_fetch_assoc($data_pinjam)) : ?>
                                    <option data-id="<?= $r['id_peminjaman'] ?>" value="<?= $r['nim'] ?> - <?= $r['nama'] ?> - <?= $r['judul'] ?> (<?= $r['kode_buku'] ?>)">
                                        Jatuh Tempo: <?= date('d/m/Y', strtotime($r['tanggal_jatuh_tempo'])) ?>
                                    </option>
                                <?php endwhile; ?>
                            </datalist>

                            <input type="hidden" name="id_peminjaman" id="id_peminjaman_real">
                            <small class="text-muted mt-2 d-block italic">Pilih data dari saran yang muncul agar sistem bisa memprosesnya.</small>
                        </div>

                        <div class="mb-4">
                            <label class="form-label small fw-bold text-uppercase">Tambah Durasi (Hari)</label>
                            <div class="input-group">
                                <input type="number" name="hari" class="form-control border-2" value="7" min="1" required>
                                <span class="input-group-text bg-light">Hari</span>
                            </div>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" name="perpanjang" class="btn btn-primary py-2 fw-bold shadow-sm">
                                <i class="bi bi-check-circle me-1"></i> Proses Perpanjangan
                            </button>
                            <a href="dashboard.php" class="btn btn-light border py-2">Batal</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-lg-5">
            <div class="alert alert-info border-0 shadow-sm">
                <h6 class="fw-bold"><i class="bi bi-info-circle me-2"></i>Petunjuk Petugas:</h6>
                <ul class="small mb-0">
                    <li>Ketikkan NIM mahasiswa atau judul buku pada kolom pencarian.</li>
                    <li><strong>Wajib memilih</strong> salah satu saran yang muncul dari daftar.</li>
                    <li>Sistem akan otomatis memperbarui tanggal jatuh tempo di data peminjaman asli.</li>
                    <li>Mahasiswa akan menerima notifikasi otomatis di akun mereka.</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<script>
// Skrip untuk menangkap ID dari datalist
document.getElementById('pencarian').addEventListener('input', function(e) {
    var input = e.target,
        list = input.getAttribute('list'),
        options = document.querySelectorAll('#' + list + ' option'),
        hiddenInput = document.getElementById('id_peminjaman_real'),
        inputValue = input.value;

    hiddenInput.value = ""; // Reset setiap kali mengetik

    for(var i = 0; i < options.length; i++) {
        var option = options[i];
        if(option.value === inputValue) {
            hiddenInput.value = option.getAttribute('data-id');
            break;
        }
    }
});

// Validasi sebelum submit
document.getElementById('formPerpanjangan').addEventListener('submit', function(e) {
    var idReal = document.getElementById('id_peminjaman_real').value;
    if(idReal === "") {
        e.preventDefault();
        alert("Silakan pilih data mahasiswa/buku dari daftar saran yang tersedia!");
    }
});
</script>

<?php require_once '../includes/footer.php'; ?>