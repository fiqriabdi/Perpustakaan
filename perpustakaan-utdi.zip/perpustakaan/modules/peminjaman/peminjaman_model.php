<?php
// modules/peminjaman/peminjaman_model.php

/**
 * Mengambil semua data laporan peminjaman dengan JOIN
 */
function getLaporanPeminjaman($conn) {
    $query = "SELECT 
                p.id_peminjaman,
                m.nim,
                m.nama as nama_mhs,
                b.kode_buku,
                b.judul,
                p.tanggal_pinjam,
                p.tanggal_kembali,
                p.status
              FROM peminjaman p
              JOIN mahasiswa m ON p.id_mahasiswa = m.id_mahasiswa
              JOIN buku b ON p.id_buku = b.id_buku
              ORDER BY p.tanggal_pinjam DESC";
    return mysqli_query($conn, $query);
}

/**
 * Proses update status buku kembali
 */
function pengembalianBuku($conn, $id_peminjaman) {
    $id_peminjaman = (int)$id_peminjaman;
    // Update status dan tanggal kembali menggunakan CURDATE() (tanggal hari ini)
    $query = "UPDATE peminjaman SET 
                status = 'dikembalikan', 
                tanggal_kembali = CURDATE() 
              WHERE id_peminjaman = '$id_peminjaman'";
    return mysqli_query($conn, $query);
}

/**
 * OPSI: Fungsi untuk filter laporan berdasarkan NIM atau Judul
 */
function filterLaporan($conn, $keyword) {
    $keyword = mysqli_real_escape_string($conn, $keyword);
    $query = "SELECT p.*, m.nim, m.nama as nama_mhs, b.kode_buku, b.judul
              FROM peminjaman p
              JOIN mahasiswa m ON p.id_mahasiswa = m.id_mahasiswa
              JOIN buku b ON p.id_buku = b.id_buku
              WHERE m.nim LIKE '%$keyword%' OR b.judul LIKE '%$keyword%'
              ORDER BY p.tanggal_pinjam DESC";
    return mysqli_query($conn, $query);
}
?>