<?php
require_once 'peminjaman_model.php';

function prosesPeminjaman($conn, $mhs_id, $buku_id) {
    return tambahPeminjaman($conn, $mhs_id, $buku_id);
}

function prosesPengembalian($conn, $p_id) {
    return pengembalianBuku($conn, $p_id);
}