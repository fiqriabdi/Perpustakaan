<?php
// modules/buku/buku_model.php

function getAllBuku($conn) {
    return mysqli_query($conn, "SELECT * FROM buku ORDER BY id_buku DESC");
}

function getBukuById($conn, $id) {
    return mysqli_query($conn, "SELECT * FROM buku WHERE id_buku='$id'");
}

function tambahBuku($conn, $data) {
    // Pengaman ?? '' mencegah Warning: Undefined array key
    $kode      = mysqli_real_escape_string($conn, $data['kode_buku'] ?? '');
    $judul     = mysqli_real_escape_string($conn, $data['judul'] ?? '');
    $pengarang = mysqli_real_escape_string($conn, $data['pengarang'] ?? '');
    $penerbit  = mysqli_real_escape_string($conn, $data['penerbit'] ?? '');
    $tahun     = mysqli_real_escape_string($conn, $data['tahun'] ?? '');
    $stok      = (int)($data['stok'] ?? 0);

    // VALIDASI: Cek duplikasi kode agar tidak Fatal Error
    $cek = mysqli_query($conn, "SELECT id_buku FROM buku WHERE kode_buku = '$kode'");
    if (mysqli_num_rows($cek) > 0) {
        return false; 
    }

    $query = "INSERT INTO buku (kode_buku, judul, pengarang, penerbit, tahun, stok) 
              VALUES ('$kode', '$judul', '$pengarang', '$penerbit', '$tahun', '$stok')";
    
    return mysqli_query($conn, $query);
}

function updateBuku($conn, $data) {
    $id        = (int)($data['id_buku'] ?? 0);
    $kode      = mysqli_real_escape_string($conn, $data['kode_buku'] ?? '');
    $judul     = mysqli_real_escape_string($conn, $data['judul'] ?? '');
    $pengarang = mysqli_real_escape_string($conn, $data['pengarang'] ?? '');
    $penerbit  = mysqli_real_escape_string($conn, $data['penerbit'] ?? '');
    $tahun     = mysqli_real_escape_string($conn, $data['tahun'] ?? '');
    $stok      = (int)($data['stok'] ?? 0);

    return mysqli_query($conn, "UPDATE buku SET 
                kode_buku='$kode', judul='$judul', pengarang='$pengarang', 
                penerbit='$penerbit', tahun='$tahun', stok='$stok' 
                WHERE id_buku='$id'");
}

function deleteBuku($conn, $id) {
    // Menghapus permanen dari database
    return mysqli_query($conn, "DELETE FROM buku WHERE id_buku='$id'");
}