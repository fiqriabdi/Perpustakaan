<?php
// modules/notifikasi/notifikasi.php

function kirimNotifikasi($conn, $user_id, $pesan) {
    $pesan_db = mysqli_real_escape_string($conn, $pesan);
    return mysqli_query($conn, "
        INSERT INTO notifikasi (id_user, pesan, status, created_at)
        VALUES ('$user_id', '$pesan_db', 'belum_dibaca', NOW())
    ");
}

function getNotifikasiUser($conn, $user_id) {
    return mysqli_query($conn, "
        SELECT * FROM notifikasi
        WHERE id_user='$user_id'
        ORDER BY created_at DESC
    ");
}