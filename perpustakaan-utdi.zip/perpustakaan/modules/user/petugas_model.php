<?php
// modules/user/petugas_model.php

function getAllPetugas($conn) {
    return mysqli_query($conn, "SELECT u.id_user, u.nama, u.username FROM petugas p JOIN users u ON p.id_user = u.id_user");
}

function getPetugasById($conn, $id) {
    return mysqli_query($conn, "SELECT * FROM users WHERE id_user = '$id'");
}

function tambahPetugas($conn, $data) {
    $nama = mysqli_real_escape_string($conn, trim($data['nama']));
    $username = mysqli_real_escape_string($conn, trim($data['username']));
    $password = md5($data['password']);

    // Validasi Username Unik
    $cek = mysqli_query($conn, "SELECT id_user FROM users WHERE username='$username'");
    if (mysqli_num_rows($cek) > 0) return false;

    // Simpan ke Tabel Users
    mysqli_query($conn, "INSERT INTO users (nama, username, password, role, status) VALUES ('$nama', '$username', '$password', 'petugas', 'aktif')");
    $id_user = mysqli_insert_id($conn);

    // Simpan ke Tabel Petugas
    return mysqli_query($conn, "INSERT INTO petugas (id_user, nama) VALUES ($id_user, '$nama')");
}

function updatePetugas($conn, $data) {
    $id_user = (int)$data['id_user'];
    $nama = mysqli_real_escape_string($conn, trim($data['nama']));
    $username = mysqli_real_escape_string($conn, trim($data['username']));
    
    // Cek username unik milik orang lain
    $cek = mysqli_query($conn, "SELECT id_user FROM users WHERE username='$username' AND id_user<>$id_user");
    if (mysqli_num_rows($cek) > 0) return false;

    $pass_update = !empty($data['password']) ? ", password='".md5($data['password'])."'" : "";
    
    mysqli_query($conn, "UPDATE users SET nama='$nama', username='$username' $pass_update WHERE id_user=$id_user");
    return mysqli_query($conn, "UPDATE petugas SET nama='$nama' WHERE id_user=$id_user");
}

function hardDeletePetugas($conn, $id) {
    // Hapus permanen dari kedua tabel
    mysqli_query($conn, "DELETE FROM petugas WHERE id_user=$id");
    return mysqli_query($conn, "DELETE FROM users WHERE id_user=$id");
}