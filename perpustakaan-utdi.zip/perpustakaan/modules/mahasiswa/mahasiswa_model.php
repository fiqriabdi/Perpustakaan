<?php
// modules/mahasiswa/mhs_model.php

function getMahasiswaByStatus($conn, $status) {
    $query = "SELECT u.id_user, u.username, m.nim, m.nama, m.prodi, m.kontak 
              FROM mahasiswa m JOIN users u ON m.id_user = u.id_user 
              WHERE u.role = 'mahasiswa' AND u.status = '$status' ORDER BY m.nim ASC";
    return mysqli_query($conn, $query);
}

function tambahMahasiswa($conn, $data) {
    $username = mysqli_real_escape_string($conn, $data['username']);
    $nama     = mysqli_real_escape_string($conn, $data['nama']);
    $nim      = mysqli_real_escape_string($conn, $data['nim']);
    $prodi    = mysqli_real_escape_string($conn, $data['prodi']);
    $kontak   = mysqli_real_escape_string($conn, $data['kontak']);
    $password = md5($data['password']);

    if (mysqli_num_rows(mysqli_query($conn, "SELECT id_user FROM users WHERE username='$username'")) > 0) return "Username sudah terdaftar!";
    if (mysqli_num_rows(mysqli_query($conn, "SELECT id_mahasiswa FROM mahasiswa WHERE nim='$nim'")) > 0) return "NIM sudah terdaftar!";

    mysqli_query($conn, "INSERT INTO users (username, password, nama, role, status) VALUES ('$username', '$password', '$nama', 'mahasiswa', 'aktif')");
    $id_user = mysqli_insert_id($conn);
    return mysqli_query($conn, "INSERT INTO mahasiswa (id_user, nim, nama, prodi, kontak) VALUES ('$id_user', '$nim', '$nama', '$prodi', '$kontak')");
}

function updateMahasiswa($conn, $data) {
    $id_user  = (int)$data['id_user'];
    $username = mysqli_real_escape_string($conn, $data['username']);
    $nama     = mysqli_real_escape_string($conn, $data['nama']);
    $nim      = mysqli_real_escape_string($conn, $data['nim']);
    $prodi    = mysqli_real_escape_string($conn, $data['prodi']);
    $kontak   = mysqli_real_escape_string($conn, $data['kontak']);
    
    // Proteksi Duplicate Entry: Cek ID orang lain
    if (mysqli_num_rows(mysqli_query($conn, "SELECT id_user FROM users WHERE username='$username' AND id_user != $id_user")) > 0) return "Username sudah dipakai orang lain!";
    if (mysqli_num_rows(mysqli_query($conn, "SELECT id_mahasiswa FROM mahasiswa WHERE nim='$nim' AND id_user != $id_user")) > 0) return "NIM sudah dipakai orang lain!";

    $q_pass = !empty($data['password']) ? ", password='".md5($data['password'])."'" : "";
    mysqli_query($conn, "UPDATE users SET username='$username', nama='$nama' $q_pass WHERE id_user=$id_user");
    return mysqli_query($conn, "UPDATE mahasiswa SET nim='$nim', nama='$nama', prodi='$prodi', kontak='$kontak' WHERE id_user=$id_user");
}

function setStatusMahasiswa($conn, $id, $status) {
    return mysqli_query($conn, "UPDATE users SET status='$status' WHERE id_user=$id");
}